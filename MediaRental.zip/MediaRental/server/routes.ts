import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, isAdmin } from "./auth";
import { insertMediaSchema, insertReservationSchema, Media, Reservation } from "@shared/schema";
import { z } from "zod";
import { addDays, differenceInDays } from "date-fns";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // API Routes
  // Media endpoints
  app.get("/api/media", async (req, res) => {
    try {
      const { search, location, type } = req.query;
      const filters: { search?: string; location?: string; type?: string } = {};
      
      if (search && typeof search === "string") {
        filters.search = search;
      }
      
      if (location && typeof location === "string") {
        filters.location = location;
      }
      
      if (type && typeof type === "string") {
        filters.type = type;
      }
      
      const mediaList = await storage.getMediaList(filters);
      res.json(mediaList);
    } catch (error) {
      console.error("Error fetching media:", error);
      res.status(500).json({ message: "Error al obtener los medios" });
    }
  });

  app.get("/api/media/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const media = await storage.getMedia(id);
      if (!media) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      res.json(media);
    } catch (error) {
      console.error("Error fetching media by id:", error);
      res.status(500).json({ message: "Error al obtener el medio" });
    }
  });

  app.post("/api/media", isAdmin, async (req, res) => {
    try {
      const validationResult = insertMediaSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: "Datos inválidos", 
          errors: validationResult.error.errors 
        });
      }
      
      const newMedia = await storage.createMedia(validationResult.data);
      res.status(201).json(newMedia);
    } catch (error) {
      console.error("Error creating media:", error);
      res.status(500).json({ message: "Error al crear el medio" });
    }
  });

  app.put("/api/media/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const existingMedia = await storage.getMedia(id);
      if (!existingMedia) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      const updatedMedia = await storage.updateMedia(id, req.body);
      res.json(updatedMedia);
    } catch (error) {
      console.error("Error updating media:", error);
      res.status(500).json({ message: "Error al actualizar el medio" });
    }
  });

  app.delete("/api/media/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const existingMedia = await storage.getMedia(id);
      if (!existingMedia) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      const result = await storage.deleteMedia(id);
      if (result) {
        res.status(204).send();
      } else {
        res.status(500).json({ message: "Error al eliminar el medio" });
      }
    } catch (error) {
      console.error("Error deleting media:", error);
      res.status(500).json({ message: "Error al eliminar el medio" });
    }
  });

  // Reservation endpoints
  app.get("/api/reservations", isAuthenticated, async (req, res) => {
    try {
      const user = req.user!;
      
      if (user.role === "admin") {
        const reservations = await storage.getAllReservations();
        return res.json(reservations);
      } else {
        const reservations = await storage.getReservationsByUser(user.id);
        return res.json(reservations);
      }
    } catch (error) {
      console.error("Error fetching reservations:", error);
      res.status(500).json({ message: "Error al obtener las reservas" });
    }
  });

  app.get("/api/reservations/:id", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const reservation = await storage.getReservation(id);
      if (!reservation) {
        return res.status(404).json({ message: "Reserva no encontrada" });
      }
      
      // Only allow users to see their own reservations (unless admin)
      if (req.user!.role !== "admin" && reservation.userId !== req.user!.id) {
        return res.status(403).json({ message: "No autorizado para ver esta reserva" });
      }
      
      res.json(reservation);
    } catch (error) {
      console.error("Error fetching reservation by id:", error);
      res.status(500).json({ message: "Error al obtener la reserva" });
    }
  });

  app.get("/api/media/:id/reservations", isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      // Only admins can see all reservations for a media
      if (req.user!.role !== "admin") {
        return res.status(403).json({ message: "No autorizado" });
      }
      
      const media = await storage.getMedia(id);
      if (!media) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      const reservations = await storage.getReservationsByMedia(id);
      res.json(reservations);
    } catch (error) {
      console.error("Error fetching media reservations:", error);
      res.status(500).json({ message: "Error al obtener las reservas del medio" });
    }
  });

  app.post("/api/reservations", isAuthenticated, async (req, res) => {
    try {
      const { mediaId, startDate, endDate } = req.body;
      
      if (!mediaId || !startDate || !endDate) {
        return res.status(400).json({ message: "Faltan datos requeridos" });
      }
      
      const mediaIdNum = parseInt(mediaId);
      if (isNaN(mediaIdNum)) {
        return res.status(400).json({ message: "ID de medio inválido" });
      }
      
      const media = await storage.getMedia(mediaIdNum);
      if (!media) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      // Parse dates
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      
      // Validate dates
      if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
        return res.status(400).json({ message: "Fechas inválidas" });
      }
      
      // Ensure start date is not in the past
      if (startDateObj < new Date()) {
        return res.status(400).json({ message: "La fecha de inicio no puede ser en el pasado" });
      }
      
      // Ensure end date is after start date
      if (endDateObj < startDateObj) {
        return res.status(400).json({ message: "La fecha de fin debe ser posterior a la fecha de inicio" });
      }
      
      // Check availability
      const isAvailable = await storage.isMediaAvailable(mediaIdNum, startDateObj, endDateObj);
      if (!isAvailable) {
        return res.status(400).json({ message: "El medio no está disponible para las fechas seleccionadas" });
      }
      
      // Calculate total price
      const days = differenceInDays(endDateObj, startDateObj) + 1; // +1 to include both start and end days
      const totalPrice = media.pricePerDay * days;
      
      const reservation: Omit<Reservation, 'id' | 'createdAt'> = {
        userId: req.user!.id,
        mediaId: mediaIdNum,
        startDate: startDateObj,
        endDate: endDateObj,
        totalPrice,
        status: "pending"
      };
      
      const newReservation = await storage.createReservation(reservation);
      
      // Simulate payment processing delay
      setTimeout(async () => {
        await storage.updateReservation(newReservation.id, "confirmed");
        console.log(`Reservation ${newReservation.id} confirmed after payment processing`);
      }, 5000);
      
      res.status(201).json(newReservation);
    } catch (error) {
      console.error("Error creating reservation:", error);
      res.status(500).json({ message: "Error al crear la reserva" });
    }
  });

  app.put("/api/reservations/:id/status", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const { status } = req.body;
      if (!status || !["pending", "confirmed", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Estado inválido" });
      }
      
      const reservation = await storage.getReservation(id);
      if (!reservation) {
        return res.status(404).json({ message: "Reserva no encontrada" });
      }
      
      const updatedReservation = await storage.updateReservation(id, status);
      res.json(updatedReservation);
    } catch (error) {
      console.error("Error updating reservation status:", error);
      res.status(500).json({ message: "Error al actualizar el estado de la reserva" });
    }
  });

  // Check media availability endpoint
  app.get("/api/media/:id/availability", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate || typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ message: "Fechas inválidas" });
      }
      
      const media = await storage.getMedia(id);
      if (!media) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      // Parse dates
      const startDateObj = new Date(startDate);
      const endDateObj = new Date(endDate);
      
      // Validate dates
      if (isNaN(startDateObj.getTime()) || isNaN(endDateObj.getTime())) {
        return res.status(400).json({ message: "Fechas inválidas" });
      }
      
      const isAvailable = await storage.isMediaAvailable(id, startDateObj, endDateObj);
      res.json({ available: isAvailable });
    } catch (error) {
      console.error("Error checking availability:", error);
      res.status(500).json({ message: "Error al verificar disponibilidad" });
    }
  });

  // Get all reservations for a specific media to show in calendar
  app.get("/api/media/:id/calendar", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "ID inválido" });
      }
      
      const media = await storage.getMedia(id);
      if (!media) {
        return res.status(404).json({ message: "Medio no encontrado" });
      }
      
      const reservations = await storage.getReservationsByMedia(id);
      
      // Only return active reservations (not cancelled)
      const activeReservations = reservations.filter(r => r.status !== "cancelled");
      
      // Only return the dates, not the full reservation details
      const bookedDates = activeReservations.map(r => ({
        startDate: r.startDate,
        endDate: r.endDate,
        status: r.status
      }));
      
      res.json(bookedDates);
    } catch (error) {
      console.error("Error fetching calendar data:", error);
      res.status(500).json({ message: "Error al obtener datos del calendario" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
