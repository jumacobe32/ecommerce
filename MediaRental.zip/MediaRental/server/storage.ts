import { users, type User, type InsertUser, Media, InsertMedia, Reservation, InsertReservation } from "@shared/schema";
import { format, addDays, isWithinInterval, parseISO } from "date-fns";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  
  // Media methods
  getMedia(id: number): Promise<Media | undefined>;
  getMediaList(filters?: {
    search?: string;
    location?: string;
    type?: string;
  }): Promise<Media[]>;
  createMedia(media: InsertMedia): Promise<Media>;
  updateMedia(id: number, media: Partial<Media>): Promise<Media | undefined>;
  deleteMedia(id: number): Promise<boolean>;
  
  // Reservation methods
  getReservation(id: number): Promise<Reservation | undefined>;
  getReservationsByUser(userId: number): Promise<Reservation[]>;
  getReservationsByMedia(mediaId: number): Promise<Reservation[]>;
  getAllReservations(): Promise<Reservation[]>;
  createReservation(reservation: InsertReservation): Promise<Reservation>;
  updateReservation(id: number, status: string): Promise<Reservation | undefined>;
  
  // Availability check
  isMediaAvailable(mediaId: number, startDate: Date, endDate: Date, excludeReservationId?: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private media: Map<number, Media>;
  private reservations: Map<number, Reservation>;
  private userIdCounter: number;
  private mediaIdCounter: number;
  private reservationIdCounter: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.media = new Map();
    this.reservations = new Map();
    this.userIdCounter = 1;
    this.mediaIdCounter = 1;
    this.reservationIdCounter = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Initialize with some demo data
    this.initDemoData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Media methods
  async getMedia(id: number): Promise<Media | undefined> {
    return this.media.get(id);
  }

  async getMediaList(filters?: {
    search?: string;
    location?: string;
    type?: string;
  }): Promise<Media[]> {
    let mediaList = Array.from(this.media.values());
    
    if (filters) {
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        mediaList = mediaList.filter(m => 
          m.name.toLowerCase().includes(searchLower) || 
          m.description?.toLowerCase().includes(searchLower) ||
          m.location.toLowerCase().includes(searchLower) ||
          m.type.toLowerCase().includes(searchLower) ||
          m.address?.toLowerCase().includes(searchLower)
        );
      }
      
      if (filters.location) {
        mediaList = mediaList.filter(m => m.location === filters.location);
      }
      
      if (filters.type) {
        mediaList = mediaList.filter(m => m.type === filters.type);
      }
    }
    
    return mediaList;
  }

  async createMedia(media: InsertMedia): Promise<Media> {
    const id = this.mediaIdCounter++;
    const createdAt = new Date();
    const newMedia: Media = { ...media, id, createdAt };
    this.media.set(id, newMedia);
    return newMedia;
  }

  async updateMedia(id: number, media: Partial<Media>): Promise<Media | undefined> {
    const existingMedia = this.media.get(id);
    if (!existingMedia) return undefined;
    
    const updatedMedia = { ...existingMedia, ...media };
    this.media.set(id, updatedMedia);
    return updatedMedia;
  }

  async deleteMedia(id: number): Promise<boolean> {
    return this.media.delete(id);
  }

  // Reservation methods
  async getReservation(id: number): Promise<Reservation | undefined> {
    return this.reservations.get(id);
  }

  async getReservationsByUser(userId: number): Promise<Reservation[]> {
    return Array.from(this.reservations.values()).filter(
      (reservation) => reservation.userId === userId
    );
  }

  async getReservationsByMedia(mediaId: number): Promise<Reservation[]> {
    return Array.from(this.reservations.values()).filter(
      (reservation) => reservation.mediaId === mediaId
    );
  }

  async getAllReservations(): Promise<Reservation[]> {
    return Array.from(this.reservations.values());
  }

  async createReservation(reservation: InsertReservation): Promise<Reservation> {
    const id = this.reservationIdCounter++;
    const createdAt = new Date();
    const newReservation: Reservation = { ...reservation, id, createdAt };
    this.reservations.set(id, newReservation);
    return newReservation;
  }

  async updateReservation(id: number, status: string): Promise<Reservation | undefined> {
    const existingReservation = this.reservations.get(id);
    if (!existingReservation) return undefined;
    
    const updatedReservation = { ...existingReservation, status };
    this.reservations.set(id, updatedReservation);
    return updatedReservation;
  }

  // Availability check
  async isMediaAvailable(mediaId: number, startDate: Date, endDate: Date, excludeReservationId?: number): Promise<boolean> {
    const media = await this.getMedia(mediaId);
    if (!media || !media.isActive) return false;
    
    const reservations = await this.getReservationsByMedia(mediaId);
    const conflictingReservation = reservations.find(res => {
      if (excludeReservationId && res.id === excludeReservationId) {
        return false;
      }
      
      // Only check confirmed and pending reservations
      if (res.status === 'cancelled') {
        return false;
      }
      
      // Check if dates overlap
      return (
        (startDate <= new Date(res.endDate) && endDate >= new Date(res.startDate))
      );
    });
    
    return !conflictingReservation;
  }

  // Initialize with demo data
  private initDemoData() {
    // Add admin user
    this.createUser({
      username: "admin",
      password: "$2b$10$X4kv7j5ZcG39WgogSl16aupodIwuGt5ZHQD5/lEMNMY3GJwJGvD1W", // "password123"
      name: "Administrador",
      email: "admin@mediabooker.com",
      role: "admin"
    });
    
    // Add client user
    this.createUser({
      username: "client",
      password: "$2b$10$X4kv7j5ZcG39WgogSl16aupodIwuGt5ZHQD5/lEMNMY3GJwJGvD1W", // "password123"
      name: "Juan Pérez",
      email: "juan@ejemplo.com",
      role: "client"
    });
    
    // Add media items
    this.createMedia({
      name: "Valla Premium Centro Comercial",
      location: "centro",
      type: "valla",
      imageUrl: "https://images.unsplash.com/photo-1558473089-c7de70fc2af0?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 350,
      description: "Valla publicitaria de gran formato ubicada en la entrada principal del centro comercial con mayor afluencia de la ciudad. Excelente visibilidad desde todos los ángulos y exposición a más de 20,000 personas diariamente.",
      dimensions: "8m x 3m",
      printType: "Digital",
      lighting: "LED 24h",
      estimatedAudience: "20,000/día",
      address: "Centro Comercial Gran Vía, Entrada Principal",
      isActive: true
    });
    
    this.createMedia({
      name: "Mupi Digital Gran Vía",
      location: "centro",
      type: "mupi",
      imageUrl: "https://images.unsplash.com/photo-1582656707566-60f88c24d534?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 250,
      description: "Mupi digital ubicado en la avenida más transitada de la ciudad. Pantalla LED de alta resolución con rotación de anuncios cada 30 segundos.",
      dimensions: "1.2m x 1.8m",
      printType: "Digital LED",
      lighting: "Integrada",
      estimatedAudience: "15,000/día",
      address: "Avenida Gran Vía 28",
      isActive: true
    });
    
    this.createMedia({
      name: "Pantalla LED Estación Central",
      location: "norte",
      type: "pantalla_led",
      imageUrl: "https://images.unsplash.com/photo-1589288415563-64fe1f663883?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 450,
      description: "Pantalla LED de gran formato ubicada en la estación central de trenes. Visualización perfecta para los miles de viajeros diarios.",
      dimensions: "6m x 4m",
      printType: "LED HD",
      lighting: "Integrada",
      estimatedAudience: "30,000/día",
      address: "Estación Central, Entrada Principal",
      isActive: true
    });
    
    this.createMedia({
      name: "Banderola Avenida Principal",
      location: "este",
      type: "banderola",
      imageUrl: "https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 180,
      description: "Banderola a doble cara situada en la avenida principal. Visibilidad para tráfico vehicular y peatonal.",
      dimensions: "0.8m x 1.2m",
      printType: "Impresión UV",
      lighting: "Nocturna",
      estimatedAudience: "10,000/día",
      address: "Avenida Principal 123",
      isActive: true
    });
    
    this.createMedia({
      name: "Cartelera Autopista Sur",
      location: "sur",
      type: "cartelera",
      imageUrl: "https://images.unsplash.com/photo-1504805572947-34fad45aed93?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 400,
      description: "Cartelera de gran formato ubicada en la autopista sur. Impacto visual garantizado para todo el tráfico hacia y desde la ciudad.",
      dimensions: "12m x 5m",
      printType: "Lona impresa",
      lighting: "Focos LED",
      estimatedAudience: "25,000/día",
      address: "Km 5 Autopista Sur",
      isActive: true
    });
    
    this.createMedia({
      name: "Mupi Parada Central",
      location: "oeste",
      type: "mupi",
      imageUrl: "https://images.unsplash.com/photo-1618761714954-0b8cd0026356?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      pricePerDay: 200,
      description: "Mupi ubicado en la parada de autobús más concurrida de la zona oeste. Ideal para campañas locales.",
      dimensions: "1.2m x 1.8m",
      printType: "Papel",
      lighting: "Interna",
      estimatedAudience: "8,000/día",
      address: "Parada Central, Avenida Oeste",
      isActive: true
    });
    
    // Add some reservations
    const today = new Date();
    this.createReservation({
      userId: 2, // client user
      mediaId: 1, // Valla Premium
      startDate: addDays(today, 10),
      endDate: addDays(today, 15),
      totalPrice: 350 * 5, // 5 days
      status: "confirmed"
    });
    
    this.createReservation({
      userId: 2, // client user
      mediaId: 2, // Mupi Digital
      startDate: new Date(today.getFullYear(), today.getMonth() - 1, 20),
      endDate: new Date(today.getFullYear(), today.getMonth() - 1, 30),
      totalPrice: 250 * 10, // 10 days
      status: "completed"
    });
    
    this.createReservation({
      userId: 2, // client user
      mediaId: 3, // Pantalla LED
      startDate: addDays(today, 20),
      endDate: addDays(today, 27),
      totalPrice: 450 * 7, // 7 days
      status: "pending"
    });
  }
}

export const storage = new MemStorage();
