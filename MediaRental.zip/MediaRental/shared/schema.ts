import { pgTable, text, serial, integer, date, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User role enum
export const userRoleEnum = pgEnum('user_role', ['admin', 'client']);

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  role: userRoleEnum("role").notNull().default('client'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Media types enum
export const mediaTypeEnum = pgEnum('media_type', ['valla', 'mupi', 'banderola', 'pantalla_led', 'cartelera']);

// Location enum
export const locationEnum = pgEnum('location', ['centro', 'norte', 'sur', 'este', 'oeste']);

// Media table
export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: locationEnum("location").notNull(),
  type: mediaTypeEnum("type").notNull(),
  imageUrl: text("image_url").notNull(),
  pricePerDay: integer("price_per_day").notNull(),
  description: text("description"),
  dimensions: text("dimensions"),
  printType: text("print_type"),
  lighting: text("lighting"),
  estimatedAudience: text("estimated_audience"),
  address: text("address"),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Reservation status enum
export const reservationStatusEnum = pgEnum('reservation_status', ['pending', 'confirmed', 'completed', 'cancelled']);

// Reservation table
export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  mediaId: integer("media_id").notNull().references(() => media.id),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  totalPrice: integer("total_price").notNull(),
  status: reservationStatusEnum("status").notNull().default('pending'),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertMediaSchema = createInsertSchema(media).omit({
  id: true,
  createdAt: true,
});

export const insertReservationSchema = createInsertSchema(reservations).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Media = typeof media.$inferSelect;
export type InsertMedia = z.infer<typeof insertMediaSchema>;

export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = z.infer<typeof insertReservationSchema>;

// Extended schemas with validation
export const loginSchema = z.object({
  username: z.string().min(3, "El nombre de usuario debe tener al menos 3 caracteres"),
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
});

export const createUserSchema = insertUserSchema.extend({
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
  email: z.string().email("Correo electrónico no válido"),
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
});

export const createMediaSchema = insertMediaSchema.extend({
  name: z.string().min(3, "El nombre debe tener al menos 3 caracteres"),
  pricePerDay: z.number().positive("El precio debe ser un número positivo"),
});

export const createReservationSchema = insertReservationSchema.extend({
  startDate: z.date().min(new Date(), "La fecha de inicio debe ser futura"),
  endDate: z.date().min(new Date(), "La fecha de fin debe ser futura"),
}).refine(data => data.endDate >= data.startDate, {
  message: "La fecha de fin debe ser posterior a la fecha de inicio",
  path: ["endDate"],
});

export type LoginData = z.infer<typeof loginSchema>;
