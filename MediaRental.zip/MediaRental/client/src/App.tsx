import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import MediaDetailPage from "@/pages/media-detail-page";
import ReservationsPage from "@/pages/reservations-page";
import AdminDashboardPage from "@/pages/admin/dashboard-page";
import AdminMediaManagementPage from "@/pages/admin/media-management-page";
import AdminReservationsPage from "@/pages/admin/reservations-page";
import { ProtectedRoute, AdminRoute } from "./lib/protected-route";
import Navbar from "./components/layout/navbar";
import Footer from "./components/layout/footer";
import { AuthProvider } from "@/hooks/use-auth";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <div className="flex-grow">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/auth" component={AuthPage} />
          <Route path="/media/:id" component={MediaDetailPage} />
          <ProtectedRoute path="/reservations" component={ReservationsPage} />
          <AdminRoute path="/admin" component={AdminDashboardPage} />
          <AdminRoute path="/admin/media" component={AdminMediaManagementPage} />
          <AdminRoute path="/admin/reservations" component={AdminReservationsPage} />
          <Route component={NotFound} />
        </Switch>
      </div>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router />
      <Toaster />
    </AuthProvider>
  );
}

export default App;
