import React from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Media } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface MediaCardProps {
  media: Media;
}

const MediaCard: React.FC<MediaCardProps> = ({ media }) => {
  const getStatusBadge = () => {
    if (!media.isActive) {
      return (
        <Badge variant="destructive" className="absolute top-2 right-2">
          No disponible
        </Badge>
      );
    }

    return (
      <Badge variant="success" className="absolute top-2 right-2 bg-green-100 text-green-800 hover:bg-green-200">
        Disponible
      </Badge>
    );
  };

  const formatLocation = (location: string) => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  const formatType = (type: string) => {
    const types: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return types[type] || type;
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition">
      <div className="relative">
        <img
          className="h-48 w-full object-cover"
          src={media.imageUrl}
          alt={media.name}
        />
        {getStatusBadge()}
      </div>
      <CardContent className="p-4">
        <h3 className="text-lg font-medium text-gray-900 truncate">{media.name}</h3>
        <p className="mt-1 text-sm text-gray-500">
          {formatLocation(media.location)} · {formatType(media.type)}
        </p>
        <div className="mt-4 flex items-center justify-between">
          <p className="text-lg font-semibold text-primary">
            €{media.pricePerDay}
            <span className="text-sm text-gray-500">/día</span>
          </p>
          <Button asChild size="sm" variant={media.isActive ? "default" : "outline"} disabled={!media.isActive}>
            <Link href={`/media/${media.id}`}>
              {media.isActive ? "Ver detalles" : "No disponible"}
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MediaCard;
