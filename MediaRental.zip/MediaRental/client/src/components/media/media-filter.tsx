import React from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface MediaFilterProps {
  search: string;
  setSearch: (value: string) => void;
  location: string;
  setLocation: (value: string) => void;
  type: string;
  setType: (value: string) => void;
  onFilter: () => void;
}

const MediaFilter: React.FC<MediaFilterProps> = ({
  search,
  setSearch,
  location,
  setLocation,
  type,
  setType,
  onFilter,
}) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilter();
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm" id="medios">
      <form onSubmit={handleSubmit} className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex-grow max-w-lg">
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Buscar por ubicación, tipo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 w-full"
            />
          </div>
        </div>
        <div className="flex space-x-2">
          <Select value={location} onValueChange={setLocation}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Ubicación" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Cualquier ubicación</SelectItem>
              <SelectItem value="centro">Centro</SelectItem>
              <SelectItem value="norte">Norte</SelectItem>
              <SelectItem value="sur">Sur</SelectItem>
              <SelectItem value="este">Este</SelectItem>
              <SelectItem value="oeste">Oeste</SelectItem>
            </SelectContent>
          </Select>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Cualquier tipo</SelectItem>
              <SelectItem value="valla">Valla</SelectItem>
              <SelectItem value="mupi">Mupi</SelectItem>
              <SelectItem value="banderola">Banderola</SelectItem>
              <SelectItem value="pantalla_led">Pantalla LED</SelectItem>
              <SelectItem value="cartelera">Cartelera</SelectItem>
            </SelectContent>
          </Select>
          <Button type="submit">Filtrar</Button>
        </div>
      </form>
    </div>
  );
};

export default MediaFilter;
