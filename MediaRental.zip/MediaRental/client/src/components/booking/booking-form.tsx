import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Media } from "@shared/schema";
import { Calendar } from "@/components/ui/calendar";
import { format, differenceInDays, addDays } from "date-fns";
import { es } from "date-fns/locale";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { DateRange } from "react-day-picker";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";

interface BookingFormProps {
  media: Media;
  bookedDates: { startDate: string | Date; endDate: string | Date; status?: string }[];
}

const formSchema = z.object({
  startDate: z.date({
    required_error: "Por favor selecciona una fecha de inicio",
  }),
  endDate: z.date({
    required_error: "Por favor selecciona una fecha de fin",
  }),
});

type FormValues = z.infer<typeof formSchema>;

const BookingForm: React.FC<BookingFormProps> = ({ media, bookedDates }) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: undefined,
    to: undefined,
  });
  const [totalDays, setTotalDays] = useState(0);
  const [totalPrice, setTotalPrice] = useState(0);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      startDate: undefined,
      endDate: undefined,
    },
  });

  useEffect(() => {
    if (dateRange?.from) {
      form.setValue("startDate", dateRange.from);
    }
    if (dateRange?.to) {
      form.setValue("endDate", dateRange.to);
    }

    if (dateRange?.from && dateRange?.to) {
      const days = differenceInDays(dateRange.to, dateRange.from) + 1;
      setTotalDays(days);
      setTotalPrice(days * media.pricePerDay);
    } else {
      setTotalDays(0);
      setTotalPrice(0);
    }
  }, [dateRange, form, media.pricePerDay]);

  const bookingMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (!user) {
        throw new Error("Debes iniciar sesión para reservar");
      }

      const payload = {
        mediaId: media.id,
        startDate: format(data.startDate, "yyyy-MM-dd"),
        endDate: format(data.endDate, "yyyy-MM-dd"),
      };

      const response = await apiRequest("POST", "/api/reservations", payload);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Reserva creada",
        description: "Tu reserva ha sido creada exitosamente.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
      navigate("/reservations");
    },
    onError: (error) => {
      toast({
        title: "Error al crear la reserva",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormValues) => {
    if (!user) {
      toast({
        title: "Debes iniciar sesión",
        description: "Inicia sesión para realizar una reserva",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }
    bookingMutation.mutate(data);
  };

  const disabledDays = {
    before: new Date(),
  };

  return (
    <Card>
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col space-y-2">
                    <FormLabel>Selecciona fechas para tu reserva</FormLabel>
                    <FormControl>
                      <Calendar
                        mode="range"
                        selected={dateRange}
                        onSelect={setDateRange}
                        bookedDates={bookedDates}
                        rangeSelection={true}
                        numberOfMonths={1}
                        disabled={[
                          ...bookedDates.map((range) => ({
                            from: new Date(range.startDate),
                            to: new Date(range.endDate),
                          })),
                          { before: new Date() },
                        ]}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-4">
                <h4 className="font-medium text-gray-900">Resumen</h4>
                <dl className="mt-2 space-y-2">
                  <div className="flex justify-between">
                    <dt className="text-sm text-gray-600">Precio por día</dt>
                    <dd className="text-sm font-medium text-gray-900">€{media.pricePerDay}</dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-sm text-gray-600">Número de días</dt>
                    <dd className="text-sm font-medium text-gray-900">{totalDays}</dd>
                  </div>
                  <div className="border-t border-gray-200 pt-2 flex justify-between">
                    <dt className="text-base font-medium text-gray-900">Total</dt>
                    <dd className="text-base font-medium text-primary">€{totalPrice}</dd>
                  </div>
                </dl>
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={bookingMutation.isPending || !dateRange?.from || !dateRange?.to}
              >
                {bookingMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Procesando
                  </>
                ) : (
                  "Confirmar reserva"
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default BookingForm;
