import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Newspaper,
  Calendar,
  Users,
  Settings,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  isActive: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  icon,
  label,
  href,
  isActive,
}) => {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
          isActive
            ? "bg-primary/10 text-primary"
            : "text-gray-600 hover:text-primary hover:bg-primary/5"
        )}
      >
        <div className="mr-3">{icon}</div>
        {label}
      </a>
    </Link>
  );
};

const AdminSidebar: React.FC = () => {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="w-64 bg-white h-full border-r border-gray-200">
      <div className="flex flex-col h-full">
        <div className="px-4 py-6">
          <h2 className="text-lg font-bold text-gray-900">Panel de Admin</h2>
          <p className="text-sm text-gray-500 mt-1">Gestión de MediaBooker</p>
        </div>
        <nav className="flex-1 px-2 space-y-1">
          <SidebarItem
            icon={<LayoutDashboard size={18} />}
            label="Dashboard"
            href="/admin"
            isActive={location === "/admin"}
          />
          <SidebarItem
            icon={<Newspaper size={18} />}
            label="Medios Publicitarios"
            href="/admin/media"
            isActive={location === "/admin/media"}
          />
          <SidebarItem
            icon={<Calendar size={18} />}
            label="Reservas"
            href="/admin/reservations"
            isActive={location === "/admin/reservations"}
          />
        </nav>
        <div className="p-4 border-t border-gray-200">
          <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
            <LogOut size={18} className="mr-2" />
            Cerrar sesión
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AdminSidebar;
