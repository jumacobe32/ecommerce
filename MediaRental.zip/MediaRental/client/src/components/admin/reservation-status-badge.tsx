import React from "react";
import { Badge } from "@/components/ui/badge";
import { getReservationStatusClass, getReservationStatusText } from "@/lib/date-utils";

interface ReservationStatusBadgeProps {
  status: string;
}

const ReservationStatusBadge: React.FC<ReservationStatusBadgeProps> = ({ status }) => {
  const statusClass = getReservationStatusClass(status);
  const statusText = getReservationStatusText(status);

  return (
    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusClass}`}>
      {statusText}
    </span>
  );
};

export default ReservationStatusBadge;
