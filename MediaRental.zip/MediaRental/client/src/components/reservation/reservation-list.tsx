import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Reservation, Media, User } from "@shared/schema";
import { formatDate, getReservationStatusClass, getReservationStatusText } from "@/lib/date-utils";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import ReservationStatusBadge from "@/components/admin/reservation-status-badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Calendar, User as UserIcon } from "lucide-react";

interface ReservationWithDetails extends Reservation {
  media: Media;
  user: Omit<User, "password">;
}

const ReservationList: React.FC<{ isAdmin?: boolean }> = ({ isAdmin = false }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: reservations, isLoading } = useQuery<ReservationWithDetails[]>({
    queryKey: ["/api/reservations"],
    queryFn: async () => {
      const response = await fetch("/api/reservations", {
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error("Error fetching reservations");
      }
      
      const reservationsData = await response.json();
      
      // Fetch media and user details for each reservation
      const reservationsWithDetails = await Promise.all(
        reservationsData.map(async (reservation: Reservation) => {
          const [mediaResponse, userResponse] = await Promise.all([
            fetch(`/api/media/${reservation.mediaId}`, { credentials: "include" }),
            isAdmin ? fetch(`/api/users/${reservation.userId}`, { credentials: "include" }).catch(() => ({ ok: false })) : Promise.resolve({ ok: false }),
          ]);
          
          let media, user;
          
          if (mediaResponse.ok) {
            media = await mediaResponse.json();
          } else {
            media = { name: "Medio no disponible", location: "desconocida", type: "desconocido" };
          }
          
          if (userResponse.ok) {
            user = await userResponse.json();
          } else {
            user = isAdmin ? { name: "Usuario desconocido", email: "No disponible" } : null;
          }
          
          return { ...reservation, media, user };
        })
      );
      
      return reservationsWithDetails;
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await apiRequest("PUT", `/api/reservations/${id}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Estado actualizado",
        description: "El estado de la reserva ha sido actualizado correctamente",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/reservations"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (id: number, status: string) => {
    updateStatusMutation.mutate({ id, status });
  };

  const formatType = (type: string) => {
    const types: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return types[type] || type;
  };

  const formatLocation = (location: string) => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white overflow-hidden shadow-sm rounded-md p-6">
            <div className="flex items-center">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="ml-4 space-y-2">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!reservations || reservations.length === 0) {
    return (
      <div className="text-center py-12 bg-white shadow-sm rounded-md">
        <Calendar className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">No hay reservas disponibles</h3>
        <p className="mt-1 text-sm text-gray-500">
          {isAdmin
            ? "No hay reservas registradas en el sistema"
            : "Explora nuestros espacios publicitarios y haz tu primera reserva"}
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white shadow-sm overflow-hidden rounded-md">
      <ul className="divide-y divide-gray-200">
        {reservations.map((reservation) => (
          <li key={reservation.id}>
            <div className="block hover:bg-gray-50">
              <div className="flex items-center px-4 py-4 sm:px-6">
                <div className="min-w-0 flex-1 flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center">
                    {isAdmin && reservation.user && (
                      <div className="flex-shrink-0 mr-4">
                        <Avatar>
                          <AvatarFallback>{getInitials(reservation.user.name)}</AvatarFallback>
                        </Avatar>
                      </div>
                    )}
                    <div className="flex-shrink-0 h-16 w-16 rounded overflow-hidden">
                      <img
                        className="h-full w-full object-cover"
                        src={reservation.media.imageUrl}
                        alt={reservation.media.name}
                      />
                    </div>
                    <div className="ml-4">
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-primary truncate">{reservation.media.name}</p>
                      </div>
                      <p className="mt-1 flex items-center text-sm text-gray-500">
                        {formatLocation(reservation.media.location)} · {formatType(reservation.media.type)}
                      </p>
                      {isAdmin && reservation.user && (
                        <p className="mt-1 flex items-center text-sm text-gray-500">
                          <UserIcon className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                          {reservation.user.name}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="mt-4 sm:mt-0 sm:ml-6 flex flex-col sm:items-end">
                    <div>
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-primary">€{reservation.totalPrice}</p>
                        <ReservationStatusBadge status={reservation.status} />
                      </div>
                      <p className="text-sm text-gray-500">
                        {formatDate(reservation.startDate)} - {formatDate(reservation.endDate)}
                      </p>
                      <p className="text-xs text-gray-500">
                        {Math.floor((new Date(reservation.endDate).getTime() - new Date(reservation.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1} días
                      </p>
                    </div>
                    
                    {isAdmin && (
                      <div className="mt-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => handleStatusChange(reservation.id, "confirmed")}
                              disabled={reservation.status === "confirmed"}
                            >
                              Marcar como confirmada
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleStatusChange(reservation.id, "completed")}
                              disabled={reservation.status === "completed"}
                            >
                              Marcar como completada
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={() => handleStatusChange(reservation.id, "cancelled")}
                              disabled={reservation.status === "cancelled"}
                            >
                              Cancelar reserva
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ReservationList;
