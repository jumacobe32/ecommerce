import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import AdminSidebar from "@/components/admin/admin-sidebar";
import { Media } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { DataTable } from "@/components/ui/data-table";
import { 
  ColumnDef, 
  ColumnFiltersState, 
  SortingState,
  VisibilityState,
  getFilteredRowModel, 
  getSortedRowModel, 
  getPaginationRowModel 
} from "@tanstack/react-table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import MediaForm from "@/components/admin/media-form";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  MoreHorizontal, 
  Trash2,
  Plus,
  ImageIcon,
  Search
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const AdminMediaManagementPage: React.FC = () => {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({});
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingMedia, setEditingMedia] = useState<Media | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<number | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: media, isLoading } = useQuery<Media[]>({
    queryKey: ["/api/media"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/media/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Medio eliminado",
        description: "El medio ha sido eliminado correctamente",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/media"] });
      setDeleteConfirmId(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatType = (type: string) => {
    const types: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return types[type] || type;
  };

  const formatLocation = (location: string) => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  const columns: ColumnDef<Media>[] = [
    {
      accessorKey: "id",
      header: "ID",
      cell: ({ row }) => <div className="text-center">{row.getValue("id")}</div>,
    },
    {
      accessorKey: "name",
      header: "Nombre",
      cell: ({ row }) => {
        return (
          <div className="flex items-center">
            <div className="flex-shrink-0 h-10 w-10 mr-2">
              {row.original.imageUrl ? (
                <img
                  className="h-10 w-10 rounded object-cover"
                  src={row.original.imageUrl}
                  alt={row.original.name}
                />
              ) : (
                <div className="h-10 w-10 rounded bg-gray-200 flex items-center justify-center">
                  <ImageIcon size={16} className="text-gray-400" />
                </div>
              )}
            </div>
            <div className="font-medium">{row.getValue("name")}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "location",
      header: "Ubicación",
      cell: ({ row }) => formatLocation(row.getValue("location")),
    },
    {
      accessorKey: "type",
      header: "Tipo",
      cell: ({ row }) => formatType(row.getValue("type")),
    },
    {
      accessorKey: "pricePerDay",
      header: "Precio/día",
      cell: ({ row }) => <div className="text-right">€{row.getValue("pricePerDay")}</div>,
    },
    {
      accessorKey: "isActive",
      header: "Estado",
      cell: ({ row }) => {
        return row.getValue("isActive") ? (
          <Badge variant="success" className="bg-green-100 text-green-800 hover:bg-green-200">
            Activo
          </Badge>
        ) : (
          <Badge variant="destructive">Inactivo</Badge>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const media = row.original;

        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Abrir menú</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Acciones</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => {
                  setEditingMedia(media);
                }}
              >
                <Edit className="mr-2 h-4 w-4" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => setDeleteConfirmId(media.id)}
                className="text-red-600"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Eliminar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        );
      },
    },
  ];

  const handleCreateMedia = () => {
    setIsCreateModalOpen(true);
  };

  const handleCloseEditModal = () => {
    setEditingMedia(null);
  };

  const handleCloseCreateModal = () => {
    setIsCreateModalOpen(false);
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate(id);
  };
  
  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />
      <div className="flex-1 overflow-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Gestión de Medios Publicitarios</h1>
          <Button onClick={handleCreateMedia}>
            <Plus className="mr-2 h-4 w-4" /> Añadir Medio
          </Button>
        </div>

        <div className="mb-4">
          <Input
            placeholder="Buscar medios..."
            value={(columnFilters.find((f) => f.id === "name")?.value as string) || ""}
            onChange={(e) =>
              setColumnFilters([
                {
                  id: "name",
                  value: e.target.value,
                },
              ])
            }
            className="max-w-sm"
            startIcon={<Search className="h-4 w-4 text-gray-400" />}
          />
        </div>

        <div className="bg-white rounded-md shadow">
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : (
            <DataTable
              columns={columns}
              data={media || []}
              sorting={sorting}
              onSortingChange={setSorting}
              columnFilters={columnFilters}
              onColumnFiltersChange={setColumnFilters}
              columnVisibility={columnVisibility}
              onColumnVisibilityChange={setColumnVisibility}
              getPaginationRowModel={getPaginationRowModel()}
              getFilteredRowModel={getFilteredRowModel()}
              getSortedRowModel={getSortedRowModel()}
            />
          )}
        </div>

        {/* Create Media Modal */}
        <MediaForm 
          open={isCreateModalOpen} 
          onClose={handleCloseCreateModal} 
        />

        {/* Edit Media Modal */}
        {editingMedia && (
          <MediaForm 
            media={editingMedia} 
            open={!!editingMedia} 
            onClose={handleCloseEditModal} 
          />
        )}

        {/* Delete Confirmation Dialog */}
        <Dialog open={!!deleteConfirmId} onOpenChange={() => setDeleteConfirmId(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>¿Estás seguro?</DialogTitle>
              <DialogDescription>
                Esta acción no se puede deshacer. Esto eliminará permanentemente este medio
                publicitario y todas sus reservas asociadas.
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setDeleteConfirmId(null)}>
                Cancelar
              </Button>
              <Button
                variant="destructive"
                onClick={() => deleteConfirmId && handleDelete(deleteConfirmId)}
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? "Eliminando..." : "Eliminar"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default AdminMediaManagementPage;
