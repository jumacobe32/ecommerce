import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import AdminSidebar from "@/components/admin/admin-sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { Media, Reservation } from "@shared/schema";
import { formatShortDate } from "@/lib/date-utils";
import { 
  LayoutDashboard, 
  UserSquare, 
  FileText, 
  Calendar,
  TrendingUp
} from "lucide-react";

const AdminDashboardPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: media } = useQuery<Media[]>({
    queryKey: ["/api/media"],
  });

  const { data: reservations } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
  });

  // Calculate dashboard metrics
  const calculateMetrics = () => {
    if (!media || !reservations) return null;

    const totalMedia = media.length;
    const activeMedia = media.filter((m) => m.isActive).length;
    const totalReservations = reservations.length;
    const pendingReservations = reservations.filter((r) => r.status === "pending").length;
    const confirmedReservations = reservations.filter((r) => r.status === "confirmed").length;
    const completedReservations = reservations.filter((r) => r.status === "completed").length;
    const cancelledReservations = reservations.filter((r) => r.status === "cancelled").length;
    
    // Calculate total revenue
    const revenue = reservations.reduce((total, reservation) => {
      if (reservation.status !== "cancelled") {
        return total + reservation.totalPrice;
      }
      return total;
    }, 0);

    return {
      totalMedia,
      activeMedia,
      totalReservations,
      pendingReservations,
      confirmedReservations,
      completedReservations,
      cancelledReservations,
      revenue,
    };
  };

  const metrics = calculateMetrics();

  // Prepare chart data
  const prepareMediaTypeData = () => {
    if (!media) return [];

    const typeCount: Record<string, number> = {};
    media.forEach((m) => {
      typeCount[m.type] = (typeCount[m.type] || 0) + 1;
    });

    return Object.entries(typeCount).map(([type, count]) => ({
      name: formatMediaType(type),
      value: count,
    }));
  };

  const prepareLocationData = () => {
    if (!media) return [];

    const locationCount: Record<string, number> = {};
    media.forEach((m) => {
      locationCount[m.location] = (locationCount[m.location] || 0) + 1;
    });

    return Object.entries(locationCount).map(([location, count]) => ({
      name: formatLocation(location),
      value: count,
    }));
  };

  const prepareStatusData = () => {
    if (!reservations) return [];

    const statusCount: Record<string, number> = {
      pending: 0,
      confirmed: 0,
      completed: 0,
      cancelled: 0,
    };

    reservations.forEach((r) => {
      statusCount[r.status] = (statusCount[r.status] || 0) + 1;
    });

    return Object.entries(statusCount).map(([status, count]) => ({
      name: formatReservationStatus(status),
      value: count,
    }));
  };

  const formatMediaType = (type: string): string => {
    const typeMap: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return typeMap[type] || type;
  };

  const formatLocation = (location: string): string => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  const formatReservationStatus = (status: string): string => {
    const statusMap: Record<string, string> = {
      pending: "Pendiente",
      confirmed: "Confirmada",
      completed: "Completada",
      cancelled: "Cancelada",
    };
    return statusMap[status] || status;
  };

  const mediaTypeData = prepareMediaTypeData();
  const locationData = prepareLocationData();
  const statusData = prepareStatusData();

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  const recentReservations = reservations
    ? [...reservations]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5)
    : [];

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />
      <div className="flex-1 overflow-auto p-6">
        <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="overview">Vista General</TabsTrigger>
            <TabsTrigger value="media">Medios</TabsTrigger>
            <TabsTrigger value="reservations">Reservas</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            {/* Overview Cards */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Medios
                  </CardTitle>
                  <LayoutDashboard className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics?.totalMedia || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {metrics?.activeMedia || 0} activos
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Total Reservas
                  </CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{metrics?.totalReservations || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {metrics?.pendingReservations || 0} pendientes
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Ingresos
                  </CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">€{metrics?.revenue || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    De {metrics?.confirmedReservations || 0} reservas confirmadas
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Tasa de Completados
                  </CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {metrics?.totalReservations
                      ? Math.round((metrics.completedReservations / metrics.totalReservations) * 100)
                      : 0}
                    %
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {metrics?.completedReservations || 0} reservas completadas
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Reservations */}
            <h2 className="text-xl font-semibold mt-8 mb-4">Reservas Recientes</h2>
            <div className="bg-white rounded-md shadow">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        ID
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Fecha
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Medio ID
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Usuario ID
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Estado
                      </th>
                      <th
                        scope="col"
                        className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Total
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {recentReservations.map((reservation) => (
                      <tr key={reservation.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {reservation.id}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatShortDate(reservation.createdAt)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {reservation.mediaId}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {reservation.userId}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              reservation.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : reservation.status === "confirmed"
                                ? "bg-green-100 text-green-800"
                                : reservation.status === "completed"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {formatReservationStatus(reservation.status)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          €{reservation.totalPrice}
                        </td>
                      </tr>
                    ))}
                    {recentReservations.length === 0 && (
                      <tr>
                        <td
                          colSpan={6}
                          className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-center"
                        >
                          No hay reservas recientes
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="media">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Distribución por Tipo</CardTitle>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={mediaTypeData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {mediaTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Distribución por Ubicación</CardTitle>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={locationData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="value" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="reservations">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Estado de Reservas</CardTitle>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={statusData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {statusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Resumen de Ingresos</CardTitle>
                </CardHeader>
                <CardContent className="h-80">
                  <div className="flex flex-col justify-center h-full">
                    <div className="text-center">
                      <div className="text-5xl font-bold text-primary">€{metrics?.revenue || 0}</div>
                      <div className="mt-2 text-sm text-muted-foreground">Total de ingresos</div>
                    </div>
                    <div className="mt-8 grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-xl font-semibold">
                          {metrics?.confirmedReservations || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Reservas confirmadas</div>
                      </div>
                      <div>
                        <div className="text-xl font-semibold">
                          {metrics?.completedReservations || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Reservas completadas</div>
                      </div>
                      <div>
                        <div className="text-xl font-semibold">
                          {metrics?.pendingReservations || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Reservas pendientes</div>
                      </div>
                      <div>
                        <div className="text-xl font-semibold">
                          {metrics?.cancelledReservations || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Reservas canceladas</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboardPage;
