import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import AdminSidebar from "@/components/admin/admin-sidebar";
import ReservationList from "@/components/reservation/reservation-list";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Reservation, Media } from "@shared/schema";
import { Search, Calendar, FileText, Clock } from "lucide-react";

const AdminReservationsPage: React.FC = () => {
  const [statusFilter, setStatusFilter] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("all");

  const { data: reservations } = useQuery<Reservation[]>({
    queryKey: ["/api/reservations"],
  });

  // Calculate reservations by status
  const calculateStatusCounts = () => {
    if (!reservations) return { pending: 0, confirmed: 0, completed: 0, cancelled: 0 };

    return reservations.reduce(
      (counts, reservation) => {
        counts[reservation.status] = (counts[reservation.status] || 0) + 1;
        return counts;
      },
      { pending: 0, confirmed: 0, completed: 0, cancelled: 0 } as Record<string, number>
    );
  };

  const statusCounts = calculateStatusCounts();

  // Format status text
  const formatStatus = (status: string): string => {
    const statusMap: Record<string, string> = {
      pending: "Pendiente",
      confirmed: "Confirmada",
      completed: "Completada",
      cancelled: "Cancelada",
    };
    return statusMap[status] || status;
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <AdminSidebar />
      <div className="flex-1 overflow-auto p-6">
        <h1 className="text-2xl font-bold mb-6">Gestión de Reservas</h1>

        {/* Status Cards */}
        <div className="grid gap-4 md:grid-cols-4 mb-8">
          <Card className={`${activeTab === "all" ? "border-primary" : ""}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Todas</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Object.values(statusCounts).reduce((sum, count) => sum + count, 0)}
              </div>
              <p className="text-xs text-muted-foreground">Total de reservas</p>
              <button
                className="text-xs text-primary mt-2"
                onClick={() => {
                  setActiveTab("all");
                  setStatusFilter("");
                }}
              >
                Ver todas
              </button>
            </CardContent>
          </Card>

          <Card className={`${activeTab === "pending" ? "border-primary" : ""}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
              <Clock className="h-4 w-4 text-yellow-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statusCounts.pending}</div>
              <p className="text-xs text-muted-foreground">Reservas por procesar</p>
              <button
                className="text-xs text-primary mt-2"
                onClick={() => {
                  setActiveTab("pending");
                  setStatusFilter("pending");
                }}
              >
                Ver pendientes
              </button>
            </CardContent>
          </Card>

          <Card className={`${activeTab === "confirmed" ? "border-primary" : ""}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Confirmadas</CardTitle>
              <Calendar className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statusCounts.confirmed}</div>
              <p className="text-xs text-muted-foreground">Reservas activas</p>
              <button
                className="text-xs text-primary mt-2"
                onClick={() => {
                  setActiveTab("confirmed");
                  setStatusFilter("confirmed");
                }}
              >
                Ver confirmadas
              </button>
            </CardContent>
          </Card>

          <Card className={`${activeTab === "completed" ? "border-primary" : ""}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completadas</CardTitle>
              <FileText className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{statusCounts.completed}</div>
              <p className="text-xs text-muted-foreground">Reservas finalizadas</p>
              <button
                className="text-xs text-primary mt-2"
                onClick={() => {
                  setActiveTab("completed");
                  setStatusFilter("completed");
                }}
              >
                Ver completadas
              </button>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative w-full sm:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Buscar por ID, usuario..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Todos</SelectItem>
              <SelectItem value="pending">Pendientes</SelectItem>
              <SelectItem value="confirmed">Confirmadas</SelectItem>
              <SelectItem value="completed">Completadas</SelectItem>
              <SelectItem value="cancelled">Canceladas</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Reservation List */}
        <ReservationList isAdmin={true} />
      </div>
    </div>
  );
};

export default AdminReservationsPage;
