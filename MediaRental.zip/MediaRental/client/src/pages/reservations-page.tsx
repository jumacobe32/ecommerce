import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Reservation, Media, User } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Calendar, MapPin } from "lucide-react";
import { Link } from "wouter";
import { formatDate, getReservationStatusClass, getReservationStatusText } from "@/lib/date-utils";
import { Skeleton } from "@/components/ui/skeleton";

const ReservationsPage: React.FC = () => {
  const { user } = useAuth();

  const { data: reservations, isLoading } = useQuery<(Reservation & { media: Media })[]>({
    queryKey: ["/api/reservations"],
    queryFn: async () => {
      const response = await fetch("/api/reservations", {
        credentials: "include",
      });
      if (!response.ok) {
        throw new Error("Error fetching reservations");
      }
      
      const reservationsData = await response.json();
      
      // Fetch media details for each reservation
      const reservationsWithMedia = await Promise.all(
        reservationsData.map(async (reservation: Reservation) => {
          const mediaResponse = await fetch(`/api/media/${reservation.mediaId}`, {
            credentials: "include",
          });
          if (!mediaResponse.ok) {
            throw new Error(`Error fetching media for reservation ${reservation.id}`);
          }
          const media = await mediaResponse.json();
          return { ...reservation, media };
        })
      );
      
      return reservationsWithMedia;
    },
  });

  const formatType = (type: string) => {
    const types: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return types[type] || type;
  };

  const formatLocation = (location: string) => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  return (
    <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Mis Reservas</h2>
      
      <div className="bg-white shadow-sm overflow-hidden sm:rounded-md">
        {isLoading ? (
          <div className="space-y-4 p-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="mb-4">
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Skeleton className="h-16 w-16 rounded" />
                    <div className="ml-4 space-y-2">
                      <Skeleton className="h-4 w-48" />
                      <Skeleton className="h-4 w-32" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : reservations && reservations.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {reservations.map((reservation) => (
              <li key={reservation.id}>
                <div className="block hover:bg-gray-50">
                  <div className="flex items-center px-4 py-4 sm:px-6">
                    <div className="min-w-0 flex-1 md:grid md:grid-cols-3 md:gap-4">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-16 w-16 rounded overflow-hidden">
                          <img
                            className="h-full w-full object-cover"
                            src={reservation.media.imageUrl}
                            alt={reservation.media.name}
                          />
                        </div>
                        <div className="ml-4">
                          <p className="text-sm font-medium text-primary truncate">
                            {reservation.media.name}
                          </p>
                          <p className="mt-1 flex items-center text-sm text-gray-500">
                            <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                            <span>
                              {formatLocation(reservation.media.location)} · {formatType(reservation.media.type)}
                            </span>
                          </p>
                        </div>
                      </div>
                      <div className="hidden md:block mt-4 md:mt-0">
                        <div>
                          <p className="text-sm text-gray-900 flex items-center">
                            <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                            Reservado del <time className="ml-1 font-medium" dateTime={reservation.startDate.toString()}>{formatDate(reservation.startDate)}</time> al <time className="ml-1 font-medium" dateTime={reservation.endDate.toString()}>{formatDate(reservation.endDate)}</time>
                          </p>
                          <p className="mt-1 flex items-center text-sm text-gray-500">
                            Duración: {Math.floor((new Date(reservation.endDate).getTime() - new Date(reservation.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1} días
                          </p>
                        </div>
                      </div>
                      <div className="hidden md:block mt-4 md:mt-0 text-right">
                        <div>
                          <p className="text-sm font-medium text-primary">
                            €{reservation.totalPrice}
                          </p>
                          <p className="mt-1 flex justify-end items-center text-sm text-gray-500">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getReservationStatusClass(reservation.status)}`}>
                              {getReservationStatusText(reservation.status)}
                            </span>
                          </p>
                        </div>
                      </div>
                    </div>
                    <div>
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-12">
            <svg
              className="mx-auto h-12 w-12 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              aria-hidden="true"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"
              />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No tienes reservas</h3>
            <p className="mt-1 text-sm text-gray-500">
              Explora nuestros espacios publicitarios y haz tu primera reserva.
            </p>
            <div className="mt-6">
              <Link
                href="/"
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              >
                Ver espacios disponibles
              </Link>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

export default ReservationsPage;
