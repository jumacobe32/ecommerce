import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Media } from "@shared/schema";
import MediaCard from "@/components/media/media-card";
import MediaFilter from "@/components/media/media-filter";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const HomePage: React.FC = () => {
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState("all");
  const [type, setType] = useState("all");
  const [appliedFilters, setAppliedFilters] = useState({
    search: "",
    location: "all",
    type: "all",
  });

  const {
    data: mediaList,
    isLoading,
    error,
  } = useQuery<Media[]>({
    queryKey: [
      "/api/media",
      appliedFilters.search,
      appliedFilters.location,
      appliedFilters.type,
    ],
    queryFn: async ({ queryKey }) => {
      const [path, search, location, type] = queryKey;
      const params = new URLSearchParams();
      if (search) params.append("search", search as string);
      if (location && location !== "all") params.append("location", location as string);
      if (type && type !== "all") params.append("type", type as string);

      const url = `${path}?${params.toString()}`;
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error("Error al cargar los medios");
      }
      return response.json();
    },
  });

  const applyFilters = () => {
    setAppliedFilters({
      search,
      location,
      type,
    });
    
    // Scroll to media section
    const mediaSection = document.getElementById("medios");
    if (mediaSection) {
      mediaSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Hero Section */}
      <div className="relative bg-gray-900 rounded-xl overflow-hidden mb-8">
        <div className="absolute inset-0">
          <img
            className="w-full h-full object-cover"
            src="https://images.unsplash.com/photo-1623681214583-ac5d2922c456?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80"
            alt="Imagen de publicidad exterior"
          />
          <div className="absolute inset-0 bg-gray-900 opacity-60"></div>
        </div>
        <div className="relative max-w-3xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
            Reserva espacios publicitarios
          </h1>
          <p className="mt-6 text-xl text-gray-300">
            Encuentra y reserva los mejores espacios para tus campañas de publicidad en toda la ciudad.
          </p>
          <div className="mt-10">
            <Button
              size="lg"
              className="inline-block"
              onClick={() => {
                const mediaSection = document.getElementById("medios");
                if (mediaSection) {
                  mediaSection.scrollIntoView({ behavior: "smooth" });
                }
              }}
            >
              Ver medios disponibles
            </Button>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <MediaFilter
        search={search}
        setSearch={setSearch}
        location={location}
        setLocation={setLocation}
        type={type}
        setType={setType}
        onFilter={applyFilters}
      />

      {/* Media Grid */}
      <div className="mt-8">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">Error al cargar los medios.</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => applyFilters()}
            >
              Reintentar
            </Button>
          </div>
        ) : (
          <>
            {mediaList && mediaList.length > 0 ? (
              <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {mediaList.map((media) => (
                  <MediaCard key={media.id} media={media} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No se encontraron medios con los filtros aplicados.</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setSearch("");
                    setLocation("all");
                    setType("all");
                    setAppliedFilters({
                      search: "",
                      location: "all",
                      type: "all",
                    });
                  }}
                >
                  Limpiar filtros
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Pagination */}
      {mediaList && mediaList.length > 0 && (
        <div className="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6 mt-8 rounded-lg">
          <div className="flex-1 flex justify-between sm:hidden">
            <Button variant="outline" size="sm" disabled>
              Anterior
            </Button>
            <Button variant="outline" size="sm" disabled>
              Siguiente
            </Button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Mostrando <span className="font-medium">1</span> a{" "}
                <span className="font-medium">{mediaList.length}</span> de{" "}
                <span className="font-medium">{mediaList.length}</span> resultados
              </p>
            </div>
            <div>
              <nav
                className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px"
                aria-label="Pagination"
              >
                <Button variant="outline" size="sm" className="rounded-l-md" disabled>
                  Anterior
                </Button>
                <Button variant="outline" size="sm" className="rounded-r-md" disabled>
                  Siguiente
                </Button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};

export default HomePage;
