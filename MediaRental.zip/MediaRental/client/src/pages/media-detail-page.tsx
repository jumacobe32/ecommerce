import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import BookingForm from "@/components/booking/booking-form";
import { Media } from "@shared/schema";
import { formatDate } from "@/lib/date-utils";

const MediaDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const mediaId = parseInt(id);

  const {
    data: media,
    isLoading: isLoadingMedia,
    error: mediaError,
  } = useQuery<Media>({
    queryKey: [`/api/media/${mediaId}`],
    enabled: !isNaN(mediaId),
  });

  const {
    data: bookedDates,
    isLoading: isLoadingDates,
  } = useQuery<{ startDate: string; endDate: string; status?: string }[]>({
    queryKey: [`/api/media/${mediaId}/calendar`],
    enabled: !isNaN(mediaId),
  });

  const isLoading = isLoadingMedia || isLoadingDates;

  const formatLocation = (location: string) => {
    return location.charAt(0).toUpperCase() + location.slice(1);
  };

  const formatType = (type: string) => {
    const types: Record<string, string> = {
      valla: "Valla",
      mupi: "Mupi",
      banderola: "Banderola",
      pantalla_led: "Pantalla LED",
      cartelera: "Cartelera",
    };
    return types[type] || type;
  };

  if (isLoading) {
    return (
      <div className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-center items-center min-h-[60vh]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (mediaError || !media) {
    return (
      <div className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-center items-center min-h-[60vh] flex-col">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Error</h2>
          <p className="text-gray-600 mb-6">No se pudo cargar la información del medio.</p>
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <Link href="/" className="inline-flex items-center text-sm text-primary hover:text-blue-600">
          <ChevronLeft className="mr-2 h-5 w-5" />
          Volver a la lista
        </Link>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 lg:gap-8">
          {/* Media Gallery */}
          <div>
            <div className="relative aspect-w-16 aspect-h-9">
              <img
                className="w-full h-96 object-cover"
                src={media.imageUrl}
                alt={media.name}
              />
            </div>
          </div>

          {/* Media Info */}
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900">{media.name}</h2>

            <div className="mt-4 flex items-center">
              {media.isActive ? (
                <Badge variant="success" className="bg-green-100 text-green-800 hover:bg-green-200">
                  Disponible
                </Badge>
              ) : (
                <Badge variant="destructive">No disponible</Badge>
              )}
              <div className="ml-4 text-sm text-gray-500">
                {formatLocation(media.location)} · {formatType(media.type)}
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-medium text-gray-900">Descripción</h3>
              <p className="mt-2 text-gray-600">{media.description}</p>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-medium text-gray-900">Especificaciones</h3>
              <dl className="mt-2 grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2">
                {media.dimensions && (
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Dimensiones</dt>
                    <dd className="mt-1 text-sm text-gray-900">{media.dimensions}</dd>
                  </div>
                )}
                {media.printType && (
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Tipo de impresión</dt>
                    <dd className="mt-1 text-sm text-gray-900">{media.printType}</dd>
                  </div>
                )}
                {media.lighting && (
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Iluminación</dt>
                    <dd className="mt-1 text-sm text-gray-900">{media.lighting}</dd>
                  </div>
                )}
                {media.estimatedAudience && (
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Audiencia estimada</dt>
                    <dd className="mt-1 text-sm text-gray-900">{media.estimatedAudience}</dd>
                  </div>
                )}
              </dl>
            </div>

            {media.address && (
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900">Ubicación</h3>
                <p className="mt-2 text-gray-600">{media.address}</p>
              </div>
            )}

            <div className="mt-8 border-t border-gray-200 pt-8">
              <div className="flex items-center justify-between">
                <p className="text-3xl font-bold text-primary">
                  €{media.pricePerDay}
                  <span className="text-sm text-gray-500">/día</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Calendar Section */}
        <div className="mt-8 p-6 border-t border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Disponibilidad</h3>
          <p className="mt-2 text-gray-600">Selecciona las fechas para tu reserva</p>

          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Booking Form with Calendar */}
            <BookingForm
              media={media}
              bookedDates={bookedDates || []}
            />
          </div>
        </div>
      </div>
    </main>
  );
};

export default MediaDetailPage;
