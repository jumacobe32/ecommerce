import { addDays, format, isSameDay, isWithinInterval, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export const formatDate = (date: Date | string): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return format(parsedDate, 'dd MMM, yyyy', { locale: es });
};

export const formatShortDate = (date: Date | string): string => {
  const parsedDate = typeof date === 'string' ? parseISO(date) : date;
  return format(parsedDate, 'dd/MM/yyyy', { locale: es });
};

export const calculateDateRange = (startDate: Date, endDate: Date): Date[] => {
  let dates: Date[] = [];
  let currentDate = startDate;
  
  while (currentDate <= endDate) {
    dates.push(new Date(currentDate));
    currentDate = addDays(currentDate, 1);
  }
  
  return dates;
};

export const isDateBooked = (
  date: Date, 
  bookedRanges: { startDate: string | Date; endDate: string | Date; status?: string }[]
): boolean => {
  return bookedRanges.some(range => {
    const start = typeof range.startDate === 'string' ? parseISO(range.startDate) : range.startDate;
    const end = typeof range.endDate === 'string' ? parseISO(range.endDate) : range.endDate;
    
    // Don't consider cancelled reservations
    if (range.status === 'cancelled') {
      return false;
    }
    
    return isWithinInterval(date, { start, end });
  });
};

export const calculateDays = (startDate: Date, endDate: Date): number => {
  return Math.abs(Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))) + 1;
};

export const calculateTotalPrice = (pricePerDay: number, startDate: Date, endDate: Date): number => {
  const days = calculateDays(startDate, endDate);
  return pricePerDay * days;
};

export const getReservationStatusText = (status: string): string => {
  switch(status) {
    case 'pending':
      return 'Pendiente';
    case 'confirmed':
      return 'Confirmada';
    case 'completed':
      return 'Completada';
    case 'cancelled':
      return 'Cancelada';
    default:
      return status;
  }
};

export const getReservationStatusClass = (status: string): string => {
  switch(status) {
    case 'pending':
      return 'bg-yellow-100 text-yellow-800';
    case 'confirmed':
      return 'bg-green-100 text-green-800';
    case 'completed':
      return 'bg-blue-100 text-blue-800';
    case 'cancelled':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};
